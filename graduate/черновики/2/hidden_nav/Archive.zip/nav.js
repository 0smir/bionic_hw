
$(document).ready(function(){
        $("#menu").mmenu();
        var API = $("#menu").data("mmenu");

        $("#mm-burger").click(function() {
            API.open();
        });





});









